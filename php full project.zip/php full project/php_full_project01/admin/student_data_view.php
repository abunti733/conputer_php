<!-- <?php 
// require("db_con.php");
// $u_id = base64_decode($_GET['u_id']);
// $data_select = mysqli_query($db_con , "SELECT * FROM `student_admission_data` WHERE `id` = '$u_id' ");
// $data_fatch = mysqli_fetch_assoc($data_select);
?> -->


<?php
session_start();
require("db_con.php");
$u_id=base64_decode($_GET['u_id']);
$_SESSION['student_id']=$id;
header('Location:admin_dashboard_index.php?page=student_profile_index');
?>
