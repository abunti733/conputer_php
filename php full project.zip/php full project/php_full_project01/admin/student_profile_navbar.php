

<?php

$student_roll=$_SESSION['student_id'];


?>

<!-- <div class="row">
//     <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 col-xxl-2">
// ghgkh;lgkh;k;flfhk
//     </div>
//     <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 col-xxl-10">
// dfdflkgdlkgmlfk


//     </div>
// </div> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
</head>
<body>
    <div class="container">
    <div class="row" >
    <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 col-xxl-2" style="width:100%;">
    <div class="nav_bar" style="border:1px solid gray;">
    <div class="img" style="text-align:center;">
        <img src="images/avator.png" alt="" style="height:120px; width:125px; border-radius:50%; border:2px solid gray; margin-top:10px;">
   
    </div>
    <span style="display:flex; justify-content:center; margin-top:10px;">bristy</span>





    <nav class="sidebar card">
    <ul class="nav flex-column" id="nav_accordion">
    <li class="nav-item has-submenu">
    
    <a class="nav-link list-group-item" href="" ><i class="fa fa-user"></i>Profile</a>
</li>	
        <li class="nav-item has-submenu">
						
        <a class="nav-link list-group-item" href="" ><i class='fas fa-graduation-cap'></i>Education </a>
    </li>	
    			
    </ul>
</nav>
</div>


        </div>
		   </div>
		      </div>

</body>
</html>