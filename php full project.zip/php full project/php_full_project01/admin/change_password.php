<?php
require("db_con.php");
if(isset($_POST['change_pass'])){
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $input_error = array();
    if(empty($old_password)){
        $input_error['old_password'] = 'old password is required !';
    }
}

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<div class="dasboard">
<h1><i class="fa-solid fa-dollar-sign  px-2" style="font-size:35px"></i>Change Password <small> Statistics Overview</small></h1>
<div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=admin_dashboard"><i class="fa-solid fa-gauge"></i>Dashboard    <i class="fa-solid fa-people-group px-2" style="font-size:18px;"></i>Chnge Password</a></div>
</div>

<form action="" method="post" style="margin-top:20px;">
  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="old_password" class="form-label">Old Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="old_password" value="old_password">
                <label class="text-danger"></label>
            </div>
        </div>
        
    <!-- end -->
    </div>
  </div>

  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="new_password" class="form-label">New Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="new_password" value="new_password">
                <label class="text-danger"></label>
            </div>
        </div>
    <!-- end -->
    </div>
  </div>

  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="confirm_password" class="form-label">Confirm Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="confirm_password" value="confirm_password">
                <label class="text-danger"></label>
            </div>
        </div>
    <!-- end -->
    </div>
  </div>
  <br/>
  <!-- submit btn start -->
  <div class="ad_btn">
    <input type="submit" value="Change Password" class="submit_btn" name="=change_pass" style="padding:10px;">

  </div>
    </form>
<script src="js/script.js"></script>





</body>
</html>